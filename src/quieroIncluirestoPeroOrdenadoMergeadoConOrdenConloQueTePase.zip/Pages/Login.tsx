import React from 'react'
import LoginComponent from '../Components/Login/LoginComponent'

const Login = () => {
  return (
    <div className='h-full w-full'>
      <LoginComponent />    
    </div>
  )
}

export default Login